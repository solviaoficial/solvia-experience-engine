import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowRight, Bot, Globe, Zap, CheckCircle2, Clock, TrendingUp, XCircle, AlertTriangle, DollarSign, PhoneOff, BellOff, UserX } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const Home = () => {
  const handleBiaClick = () => {
    window.open(
      "https://wa.me/5511918560216?text=Oi%20Bia!%20Quero%20tirar%20d%C3%BAvidas",
      "_blank"
    );
  };

  const pains = [
    {
      icon: PhoneOff,
      title: "Lead entra. Ninguém atende.",
      description: "Você investe em anúncio, o cliente manda mensagem às 22h — e vai embora pra concorrência que respondeu primeiro.",
    },
    {
      icon: UserX,
      title: "Vendedor gasta tempo com curioso",
      description: "Seu time humano para de vender para responder 'quanto custa?' e 'vocês atendem minha cidade?'. Todo dia.",
    },
    {
      icon: BellOff,
      title: "Follow-up esquecido = dinheiro perdido",
      description: "Lead quente fica frio porque ninguém lembrou de ligar. O pipeline vira cemitério de oportunidades.",
    },
    {
      icon: DollarSign,
      title: "Atendimento 24/7 custa caro demais",
      description: "Contratar plantão noturno ou final de semana é inviável. Mas deixar o cliente esperando também custa.",
    },
  ];

  const solutions = [
    {
      icon: Bot,
      title: "Agente de IA 24/7",
      description: "Responde, qualifica e agenda em segundos. A qualquer hora. Sem folga, sem atestado, sem salário.",
      features: ["Responde em menos de 5 segundos", "Qualifica e filtra leads automaticamente", "Agenda reuniões na sua agenda em tempo real"],
    },
    {
      icon: Globe,
      title: "Site que converte, não só aparece",
      description: "Design rápido, SEO técnico e IA integrada. Seu site vira vendedor ativo, não vitrine parada.",
      features: ["Carregamento abaixo de 2s (Core Web Vitals)", "SEO que traz leads orgânicos", "IA integrada para capturar visitante na hora"],
    },
    {
      icon: Zap,
      title: "Automações que fecham ciclos",
      description: "WhatsApp, CRM, agenda e pagamentos conectados. Informação certa, na hora certa, sem intervenção humana.",
      features: ["Zero retrabalho manual", "Notificações e follow-ups automáticos", "Integração com ferramentas que você já usa"],
    },
  ];

  const cases = [
    {
      company: "E-commerce Fashion",
      challenge: "Perdia leads fora do horário comercial — sem resposta, o cliente sumia.",
      solution: "Agente IA atendendo 24/7 com qualificação automática e handoff para vendedor humano.",
      result: "+47% leads qualificados · Tempo de resposta: de horas para segundos",
    },
    {
      company: "Clínica Médica",
      challenge: "Agenda cheia de 'talvez' e site lento que espantava pacientes novos.",
      solution: "Novo site com IA integrada + agendamento automático com confirmação por WhatsApp.",
      result: "LCP 1.9s · +38% agendamentos · Recepcionista libera 3h/dia",
    },
  ];

  const timeline = [
    { step: "01", title: "Diagnóstico do funil", description: "Mapeamos onde seus leads somem e quanto isso custa por mês" },
    { step: "02", title: "Protótipo em 48h", description: "Você vê o agente funcionando antes de assinar qualquer coisa" },
    { step: "03", title: "Integração & testes", description: "Conectamos com seu CRM, WhatsApp e agenda — LGPD em dia" },
    { step: "04", title: "Go live + evolução", description: "Agente no ar e melhora com cada conversa" },
  ];

  const faqs = [
    {
      question: "Meu negócio é pequeno. Vale a pena?",
      answer: "Especialmente para pequenos negócios — porque cada lead perdido dói mais. Um agente de IA custa menos que um atendente part-time e trabalha sem parar. A maioria dos nossos clientes paga o investimento com os leads que antes simplesmente sumiam.",
    },
    {
      question: "Quanto tempo até estar no ar?",
      answer: "Agentes simples de atendimento entram no ar em 3 a 5 dias úteis. Projetos completos com site + integrações levam de 2 a 4 semanas. O protótipo você vê em 48h.",
    },
    {
      question: "E se o cliente perguntar algo que o agente não sabe?",
      answer: "O agente reconhece o limite e faz o handoff para um humano — com todo o contexto da conversa já salvo. Sem constrangimento, sem cliente repetindo tudo de novo.",
    },
    {
      question: "Como a IA entra no meu WhatsApp ou site?",
      answer: "Via WhatsApp Business API, chat no site, Instagram ou Messenger. Você escolhe o canal onde seu cliente já está. Sem precisar mudar nada do seu processo atual.",
    },
  ];

  return (
    <div className="flex flex-col">

      {/* ── HERO ── */}
      <section className="relative overflow-hidden bg-background">
        <div className="container mx-auto px-4 py-24 md:py-36">
          <div className="max-w-4xl mx-auto text-center">

            {/* Eyebrow urgente */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 bg-destructive/10 text-destructive border border-destructive/20 rounded-full px-4 py-1.5 text-sm font-semibold mb-8"
            >
              <AlertTriangle className="h-4 w-4" />
              Seu concorrente já está usando IA. Você ainda não.
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-5xl md:text-7xl font-montserrat font-extrabold mb-6 leading-tight"
            >
              Pare de perder leads{" "}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                toda noite e todo fim de semana
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl md:text-2xl text-muted-foreground mb-4"
            >
              Agentes de IA que respondem em segundos, qualificam e agendam — enquanto você dorme, viaja ou descansa.
            </motion.p>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.25 }}
              className="text-base text-muted-foreground/70 mb-10"
            >
              Sem contratar mais gente. Sem plantão. Sem deixar cliente esperando.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button
                onClick={handleBiaClick}
                size="lg"
                className="gradient-primary hover:opacity-90 transition-smooth text-lg px-8 py-6"
              >
                Testar agente agora — grátis
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button asChild size="lg" variant="outline" className="text-lg px-8 py-6">
                <Link to="/contato">Ver quanto custa</Link>
              </Button>
            </motion.div>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="mt-5 text-xs text-muted-foreground"
            >
              Protótipo em 48h · Sem contrato de fidelidade · LGPD compliant
            </motion.p>
          </div>
        </div>

        {/* glow de fundo */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />
        </div>
      </section>

      {/* ── SEÇÃO DE DOR ── */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <p className="text-sm font-semibold text-destructive uppercase tracking-widest mb-3">Isso está acontecendo agora no seu negócio</p>
            <h2 className="text-4xl md:text-5xl font-montserrat font-extrabold mb-4">
              Quanto dinheiro está{" "}
              <span className="text-destructive">escapando pelo vão</span>?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Cada lead não respondido é uma venda que foi direto para o concorrente.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {pains.map((pain, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="shadow-soft border-destructive/10 h-full">
                  <CardHeader className="flex flex-row items-start gap-4 pb-2">
                    <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center shrink-0 mt-1">
                      <pain.icon className="h-5 w-5 text-destructive" />
                    </div>
                    <div>
                      <CardTitle className="text-lg leading-snug">{pain.title}</CardTitle>
                      <CardDescription className="text-base mt-1">{pain.description}</CardDescription>
                    </div>
                  </CardHeader>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* CTA dentro da seção de dor */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="text-center mt-12"
          >
            <p className="text-lg text-muted-foreground mb-4">A Solvia resolve cada um desses pontos — com agentes de IA que nunca dormem.</p>
            <Button
              onClick={handleBiaClick}
              size="lg"
              className="gradient-primary hover:opacity-90 transition-smooth"
            >
              Quero resolver isso agora
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        </div>
      </section>

      {/* ── O QUE FAZEMOS (solução) ── */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <p className="text-sm font-semibold text-primary uppercase tracking-widest mb-3">A virada</p>
            <h2 className="text-4xl md:text-5xl font-montserrat font-extrabold mb-4">
              O que entregamos
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Três soluções que eliminam os buracos no seu funil — juntas ou separadas, dependendo do que você precisa.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {solutions.map((solution, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="shadow-soft hover:shadow-medium transition-smooth h-full">
                  <CardHeader>
                    <div className="w-12 h-12 rounded-2xl gradient-primary flex items-center justify-center mb-4">
                      <solution.icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-2xl">{solution.title}</CardTitle>
                    <CardDescription className="text-base">{solution.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {solution.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center gap-2 text-sm">
                          <CheckCircle2 className="h-4 w-4 text-accent shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CASES (antes/depois) ── */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <p className="text-sm font-semibold text-primary uppercase tracking-widest mb-3">Resultados reais</p>
            <h2 className="text-4xl md:text-5xl font-montserrat font-extrabold mb-4">
              Antes e depois com a Solvia
            </h2>
            <p className="text-xl text-muted-foreground">Números de clientes que pararam de perder leads.</p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-12">
            {cases.map((case_, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="shadow-soft h-full">
                  <CardHeader>
                    <CardTitle className="text-xl">{case_.company}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <XCircle className="h-4 w-4 text-destructive" />
                        <span className="font-semibold text-sm text-destructive">Problema</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{case_.challenge}</p>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <Zap className="h-4 w-4 text-accent" />
                        <span className="font-semibold text-sm">Solução</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{case_.solution}</p>
                    </div>
                    <div className="bg-primary/5 rounded-xl p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <TrendingUp className="h-4 w-4 text-primary" />
                        <span className="font-semibold text-sm text-primary">Resultado</span>
                      </div>
                      <p className="text-sm font-semibold text-primary">{case_.result}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-center"
          >
            <Button asChild variant="outline" size="lg">
              <Link to="/cases">
                Ver demonstrações ao vivo
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>

      {/* ── COMO FUNCIONA ── */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <p className="text-sm font-semibold text-primary uppercase tracking-widest mb-3">Do zero ao ar</p>
            <h2 className="text-4xl md:text-5xl font-montserrat font-extrabold mb-4">
              Você vê funcionando antes de pagar
            </h2>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            <div className="relative">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ duration: 0.5, delay: index * 0.15 }}
                  className="flex gap-6 mb-12 last:mb-0"
                >
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-white font-bold text-sm shadow-medium">
                      {item.step}
                    </div>
                    {index < timeline.length - 1 && (
                      <div className="w-0.5 h-full bg-gradient-to-b from-primary to-accent mt-2" />
                    )}
                  </div>
                  <div className="flex-1 pb-12">
                    <h3 className="text-2xl font-montserrat font-bold mb-2">{item.title}</h3>
                    <p className="text-muted-foreground">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-24 bg-muted/30">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-montserrat font-extrabold mb-4">
              Dúvidas frequentes
            </h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Accordion type="single" collapsible className="max-w-3xl mx-auto">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left text-lg font-semibold">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </section>

      {/* ── CTA FINAL ── */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto text-center"
          >
            <p className="text-sm font-semibold text-destructive uppercase tracking-widest mb-4">Cada dia sem isso é dinheiro perdido</p>
            <h2 className="text-4xl md:text-5xl font-montserrat font-extrabold mb-6">
              Quanto vale um lead que não some mais?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Converse com a Bia — nossa IA de vendas — e veja ao vivo o que ela faz pelo seu negócio.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={handleBiaClick}
                size="lg"
                className="gradient-primary hover:opacity-90 transition-smooth text-lg px-8 py-6"
              >
                Testar a Bia agora — é grátis
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button asChild size="lg" variant="outline" className="text-lg px-8 py-6">
                <Link to="/contato">Pedir orçamento</Link>
              </Button>
            </div>
            <p className="mt-6 text-sm text-muted-foreground">
              Protótipo em 48h · Sem contrato de fidelidade · LGPD compliant
            </p>
          </motion.div>
        </div>
      </section>

    </div>
  );
};

export default Home;
